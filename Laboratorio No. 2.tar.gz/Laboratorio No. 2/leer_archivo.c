#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>

int main() {
    int fd = open("archivo.txt", O_RDONLY);
    if (fd < 0) {
        perror("Error al abrir el archivo");
        return 1;
    }

    char buffer[100];
    ssize_t bytes = read(fd, buffer, sizeof(buffer) - 1);
    if (bytes >= 0) {
        buffer[bytes] = '\0';
        printf("Contenido leído:\n%s\n", buffer);
    } else {
        perror("Error al leer");
    }

    close(fd);
    return 0;
}
