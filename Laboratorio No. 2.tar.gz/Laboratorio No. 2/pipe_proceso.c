#include <stdio.h>
#include <unistd.h>
#include <string.h>

int main() {
    int fd[2];
    pipe(fd);

    if (fork() == 0) {
        // Hijo
        close(fd[1]);  // Cierra escritura
        char buffer[100];
        read(fd[0], buffer, sizeof(buffer));
        printf("Hijo leyó: %s\n", buffer);
        close(fd[0]);
    } else {
        // Padre
        close(fd[0]);  // Cierra lectura
        char mensaje[] = "Hola desde el padre";
        write(fd[1], mensaje, strlen(mensaje) + 1);
        close(fd[1]);
    }

    return 0;
}
