#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    pid_t pid = fork();

    if (pid == 0) {
        // Proceso hijo
        printf("Soy el hijo. Mi PID es %d\n", getpid());
        execlp("ls", "ls", "-l", NULL);
        perror("Fallo exec");
    } else if (pid > 0) {
        // Proceso padre
        wait(NULL);
        printf("Proceso hijo finalizado\n");
    } else {
        perror("Error al crear proceso");
    }

    return 0;
}
